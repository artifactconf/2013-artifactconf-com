<?php 
$config = array(
	"root" => "/dev/"
);

?>