<?php 
    include('inc/config.php');
    
    $page = 'privacy';
    include('inc/header.php'); 
?>


                   
					
					<div id="privacy" class="section generic-content">
                      
                            <h2 class="section-header">Sponsorships</h2>
                            
                            <div class="content">
                               
                               
                              If you would like to sponsor the Artifact conference, please email <a href="mailto:e4h@heatvision.com" title="">e4h@heatvision.com</a>.

                            </div>

                           
                   
                    </div> 

                </div>
					
                   

<?php 
    include('inc/footer.php'); 
?>
