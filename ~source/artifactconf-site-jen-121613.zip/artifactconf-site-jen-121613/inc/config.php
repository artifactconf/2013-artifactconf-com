<?php 
$config = array(
	"root" => "/"
);

?>